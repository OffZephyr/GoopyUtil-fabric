package net.zephyr.goopyutil.blocks.computer.Apps;

import net.minecraft.util.Identifier;
import net.zephyr.goopyutil.util.Computer.ComputerApp;

public class MusicApp extends ComputerApp {
    public MusicApp(String name, Identifier iconTexture) {
        super(name, iconTexture);
    }

    @Override
    public void init() {
    }

    @Override
    public void tickWhenOpen() {
    }
    @Override
    public void tickAlways() {
    }
}
