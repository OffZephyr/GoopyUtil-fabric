package net.zephyr.goopyutil.item;

import net.minecraft.item.Item;

public class FloppyDiskItem extends ItemWithDescription {
    public FloppyDiskItem(Settings settings, int... tools) {
        super(settings, ItemWithDescription.COMPUTER);
    }
}
