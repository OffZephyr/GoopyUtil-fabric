package net.zephyr.goopyutil.blocks.computer.Apps;

import net.minecraft.util.Identifier;
import net.zephyr.goopyutil.client.gui.screens.GoopyScreen;
import net.zephyr.goopyutil.util.Computer.ComputerApp;

public class BrowserApp extends ComputerApp {
    public BrowserApp(String name, Identifier iconTexture) {
        super(name, iconTexture);
    }

    @Override
    public void init() {
    }

    @Override
    public void tickWhenOpen() {
    }
    @Override
    public void tickAlways() {
    }
}
